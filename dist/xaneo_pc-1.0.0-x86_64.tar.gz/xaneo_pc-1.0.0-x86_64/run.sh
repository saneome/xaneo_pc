#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:$SCRIPT_DIR/data:$LD_LIBRARY_PATH"
export PATH="$SCRIPT_DIR:$PATH"
./xaneo_pc_new "$@"
